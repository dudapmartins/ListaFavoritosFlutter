package com.example.revisao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
